<?php if (!$post->is_published()) : ?>
	<div class="post_unpublished_wrapper">
		<div class="post_unpublished">
			This post is currently not published and is only viewable to you because you are currently logged into FUEL.
		</div>
	</div>
<?php endif; ?>