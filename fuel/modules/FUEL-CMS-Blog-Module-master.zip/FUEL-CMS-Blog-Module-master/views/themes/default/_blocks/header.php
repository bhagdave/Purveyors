<?=css('blog')?>
<link rel="alternate" type="application/atom+xml" href="<?=$this->fuel_blog->feed('atom')?>" />
<link rel="alternate" type="application/rss+xml" title="RSS" href="<?=$this->fuel_blog->feed('rss')?>" />
