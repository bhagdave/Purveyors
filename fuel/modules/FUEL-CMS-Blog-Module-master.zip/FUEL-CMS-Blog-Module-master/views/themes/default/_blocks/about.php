<div class="blog_block">
	<h3>About</h3>
	<p><?=$this->fuel->blog->config('description')?></p>
</div>