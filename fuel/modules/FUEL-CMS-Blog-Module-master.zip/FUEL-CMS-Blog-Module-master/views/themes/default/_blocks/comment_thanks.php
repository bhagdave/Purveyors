<h3>Thanks for the comment.</h3>
<?php if ($this->fuel->blog->config('monitor_comments')){ ?>
	<p class="success">Comments for this posting are being monitored and will be published upon the author's approval.</p>
<?php } ?>
