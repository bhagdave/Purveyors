<h1><?=$this->fuel->blog->config('title')?></h1>

<?=$this->fuel->blog->block('posts')?>