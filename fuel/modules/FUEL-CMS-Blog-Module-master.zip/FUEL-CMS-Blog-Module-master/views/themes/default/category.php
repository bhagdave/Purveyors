<h1><?=$category->name?> Posts</h1>

<?=$this->fuel_blog->block('posts')?>