<?php 
define('BLOG_VERSION', '1.0');
define('BLOG_FOLDER', 'blog');
define('BLOG_PATH', MODULES_PATH.BLOG_FOLDER.'/');